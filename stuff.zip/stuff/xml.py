import xml.etree.ElementTree as ET

postMap = ET.parse("locations.xml")
postMapRoot = postMap.getroot()
i = 0

county = {}
for element in postMapRoot:
    if(element[3].text == "EE"):
        
        if(not county.get(element[4].text)):
            county.update({element[4].text : 1})
        else:
            county.update({element[4].text: county.get(element[4].text) + 1})
print(county)


total = 0
for item in county:
    total = total + county.get(item)
print(total)
