function buildMenu(menuPlace){
    document.styleSheets[0].insertRule(".mainMenuItem{display:inline-block; width:auto; margin:5px 1px; background-color:#516387; color:#CCC;padding:2px 0px; cursor:pointer; vertical-align:top; font-family:sans-serif; font-size:14px; height:16px; overflow:hidden;}");
    document.styleSheets[1].insertRule(".mainMenuItem:hover{ background-color:#8194B9; height:auto; color:white;}");
    document.styleSheets[2].insertRule(".mainMenuSubItem{width:100%; height:auto; padding:2px 10px;}");
    document.styleSheets[3].insertRule(".mainMenuSubItem:hover{background-color:rgba(255,255,255,0.3);}");
    menu = Array()
    menuObject = document.getElementById(menuPlace);
    N = menuObject.childNodes.length;
    menuCount = 0;

    for(i = 0; i < N; i++){
        if(menuObject.childNodes[i].nodeType == 1 && menuObject.childNodes[i].nodeName=='LI'){
            if(typeof(tempArr)!="undefined"){
                menu.push(tempArr);
                delete tempArr;
            }
            tempArr = Array(menuObject.childNodes[i].innerHTML);
        }
        else if(menuObject.childNodes[i].nodeType == 1 && menuObject.childNodes[i].nodeName == 'UL'){
            subMenu = menuObject.childNodes[i];
            M = subMenu.childNodes.length;
            for(j = 0; j < M; j++){
                if(subMenu.childNodes[j].nodeType == 1 && subMenu.childNodes[j].nodeName == 'LI'){
                    tempArr.push(subMenu.childNodes[j].innerHTML)
                }
            }
            if(typeof(tempArr)!="undefined"){
                menu.push(tempArr);
                delete tempArr;
            }

        } 
    }
    //alert(menu);
    document.getElementById(menuPlace).innerHTML = "";
    for(i = 0; i < menu.length; i++){
        tmpTag = document.createElement("div");
        for(j = 0; j < menu[i].length; j++){
            tmp2Tag = document.createElement("div");
            tmp2Tag.innerHTML=menu[i][j];
            tmp2Tag.className="mainMenuSubItem";
            //tmp2Tag.setAttribute("onHover","")
            tmpTag.appendChild(tmp2Tag);
        }
        document.getElementById(menuPlace).appendChild(tmpTag);
    }
}

var timer;
function openIt(something = null, menuArr = menu){
    for(i = 0; i < menuArr.length; i++){
        document.getElementById("menu1L"+(i+1)).style.height = "16px";
    }
    if(something != null){
        something.style.height="auto";
        clearTimeout(timer);
        closeIt(something);
        timer = setTimeout("openIt()", 2000)
    }
        
}